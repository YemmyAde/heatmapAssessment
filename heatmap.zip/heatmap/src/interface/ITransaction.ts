export interface ITransaction {
    transactionType?: string,
    date?: string ,
    amount?: number
}